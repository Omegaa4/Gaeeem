using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//This script was made by Alexander Yong, modified from the 28 Aug 2018 blackthornprod inventory tutorial
public class NewBehaviourScript : MonoBehaviour
{
    public bool[] isFull;       //A boolean array that is used to check if an inventory slot is full or empty
    public GameObject[] slots; //Array for referencing the slots 
    

}
